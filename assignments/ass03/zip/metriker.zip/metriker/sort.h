#ifndef _SORT_H
#define _SORT_H

void bubble_sort(int *array, int size);
void insert_sort(int *array, int size);
void quick_sort(int *array, int size);
void select_sort(int *array, int size);

#endif